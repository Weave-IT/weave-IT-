import "./menu.css";
import { PhotoshopPicker } from "react-color";
import { useState } from "react";
import { getRecord } from "./back";
function Menu({
  setShow,
  currentCol,
  setCurrentCol,
  setRepeatModalShow,
  onCapturePNG,
  onCaptureJPG,
  setBoxSize,
  datasRef,

  clearListRef,
}) {
  const [isColorPickerOpen, setisColorPickerOpen] = useState(false);
  const [color, setColor] = useState(currentCol);
  return (
    <div className="menu">
      <div className="menu-row">
        <div onClick={() => clearListRef.current()}>새파일</div>
        <div
          onClick={() => {
            const {
              setTreadlsColList,
              setShaftsColList,
              setTreadlsList,
              setShaftsList,
              setLastList,
            } = datasRef.current;
            getRecord(
              setTreadlsList,
              setShaftsList,
              setTreadlsColList,
              setShaftsColList,
              setLastList
            );
          }}
        >
          되돌리기
        </div>
      </div>
      <div className="menu-row">
        <div onClick={() => onCapturePNG()}>PNG로 저장</div>
        <div onClick={() => setRepeatModalShow(true)}>Repeat</div>
      </div>
      <div className="menu-row">
        <div onClick={() => onCaptureJPG()}>JPG로 저장</div>
        <div onClick={() => setBoxSize((s) => s - 1)}>축소</div>
      </div>
      <div className="menu-row">
        <div onClick={() => setShow(true)}>설정</div>
        <div onClick={() => setBoxSize((s) => s + 1)}>확대</div>
      </div>
      <div className="menu-row">
        <div></div>
        <div onClick={() => setisColorPickerOpen(true)}>색상</div>
      </div>
      <PhotoshopPicker
        className={`photoshop-colPick ${isColorPickerOpen ? "open" : ""}`}
        color={color}
        onChangeComplete={(color) => setColor(color.hex)}
        onAccept={() => {
          setisColorPickerOpen(false);
          setCurrentCol(color);
        }}
        onCancel={() => setisColorPickerOpen(false)}
      />
    </div>
  );
}
export default Menu;
