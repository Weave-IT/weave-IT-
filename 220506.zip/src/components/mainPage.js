import Header from "./header";
import "./mainPage.css";
export default function MainPage() {
  return (
    <div className="mainPage">
      <div className="mainPageTitle">
        <Header />
      </div>
    </div>
  );
}
